var questao1
var questao2
function carregadados(){
    questao1=document.getElementsByName("questao1")  
    questao1salva=localStorage.getItem('questao1') 
    questao1[questao1salva].checked=true

    questao2=document.getElementById("responder2")
    questao2salva=localStorage.getItem("questao2")

    questao2.value=questao2salva
    desabilitacampos()
}

function desabilitacampos(){
    for(i=0; i<questao1.length; i++){
       questao1[i].disabled=true

    }
    document.getElementById('responder').disabled = true;
    document.getElementById('botsave').disabled = true;
    questao2.disabled=true
}