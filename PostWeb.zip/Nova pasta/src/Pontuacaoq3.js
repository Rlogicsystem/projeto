var pontos = 0
function validar2(){
    var opcoes = document.getElementById('responder2')
    alert ("Sua resposta foi salva com sucesso")
    opcoes.disabled=true
    document.getElementById('botsave').disabled=true
  
}

function mostrarPontuacao(){
    var pontos =  localStorage.getItem('pontuacao');
    if(pontos == undefined){
        document.getElementById('pontos').innerText = "0,00"
    }else{
        document.getElementById('pontos').innerText = pontos
    }

}