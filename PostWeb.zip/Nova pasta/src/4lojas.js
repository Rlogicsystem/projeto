
function decrementarpontuacao(subtrair,item){
    pontuacao=localStorage.getItem("pontuacao")
    if ((pontuacao-subtrair)<0){
        alert("Pontos insuficientes")
    }else{
    pontuacao=pontuacao-subtrair
    localStorage.setItem("pontuacao",pontuacao)
    alert("Parabéns, você adquiriu um(a) "+item)
    }
    atualizapontos()
}

function atualizapontos(){
    pontuacaosalva=localStorage.getItem("pontuacao")
    document.getElementById('pontos').innerText = pontuacaosalva
}
