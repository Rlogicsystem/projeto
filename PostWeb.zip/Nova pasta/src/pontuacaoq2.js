var pontos = 0
function validar2(){
    var questao2 = document.getElementById('responder2')
    alert ("Sua resposta foi salva com sucesso")
    questao2.disabled=true
    document.getElementById('botsave').disabled=true
    localStorage.setItem ('questao2', questao2.value)
}

function mostrarPontuacao(){
    var pontos =  localStorage.getItem('pontuacao');
    if(pontos == undefined){
        document.getElementById('pontos').innerText = "0,00"
    }else{
        document.getElementById('pontos').innerText = pontos
    }

}