var questao 
function salvadados(){
    questao=document.getElementById('responder2')
    localStorage.setItem ('textareaconjunto', questao.value)
    alert ("Sua resposta foi salva com sucesso")
    desabilitacampos()

 
}

function desabilitacampos(){
    document.getElementsByName('botsave').disabled = true;
    document.getElementById('responder2').disabled = true;
    questao.disabled=true

}
function carregadados(){
    questao=document.getElementById("responder2")
    questaoretorna=localStorage.getItem("textareaconjunto")
    questao.value=questaoretorna
    //desabilitacampos()
    if (questaoretorna!=null){
        desabilitacampos()
    }
}