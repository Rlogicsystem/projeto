
function desabilitabotao(){
   // questao=document.getElementsByName('botsalvar')
    //questao=localStorage.getElementById('respondendo')
    //questao.checked=true

}
function validacao(){
    var opcoes = document.getElementById('respondendo')
   // opcoes.disabled=true
   //document.getElementById('botsalvar').disabled=true
}