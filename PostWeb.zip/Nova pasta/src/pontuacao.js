/*PRIMEIRA QUESTAO*/
var pontos = 0

function validarRepostas(){
    var opcoes = document.getElementsByName('questao1')
    var testaMarcado = false;
    if(opcoes[0].checked){
        pontos = pontos + 100
        alert("Parabéns você marcou a resposta correta!")
    }else{
        alert("Resposta errada!")
    }
    localStorage.setItem('pontuacao', pontos)


    for(i=0; i<opcoes.length; i++){
        if(opcoes[i].checked){
            testaMarcado = true
            localStorage.setItem("questao1",i)
        }
    }

    if(testaMarcado){
        document.getElementById('responder').disabled = true;
    }
}

function mostrarPontuacao(){
    var pontos =  localStorage.getItem('pontuacao');
    if(pontos == undefined){
        document.getElementById('pontos').innerText = "0,00"
    }else{
        document.getElementById('pontos').innerText = pontos
    }

}
